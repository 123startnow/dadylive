<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Contact Us! | Daddylive.live</title>
</head>
<body>
<center><img src="https://i.imgur.com/OJvZmwG.png" width="913" height="114" class="aligncenter size-full" /></center>
<h1 style="text-align: center;"><a href="/cdn-cgi/l/email-protection#72161316160b1e1b04174532151f131b1e5c111d1f"><span style="color: #ff0000;"><span style="color: #000000;">E-Mail us</span> : <span class="__cf_email__" data-cfemail="3c585d58584550554a590b7c5b515d5550125f5351">[email&#160;protected]</span></span></a></h1>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script></body>
</html>