<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Daddylive.Live - Live Sports Streaming - Best streaming site</title>
<meta name="keywords" content="Watch Live Sports, boxing & mma, College Basketball, UFC, MBA, MLB, NHL, NFL Games, Soccer, Live Streams, 24/7 updated live stream, Enjoy Football" />
<meta name="description" content="Free live sports streaming in HD,  Get Games and Sports live stream for free, Watch Matches Online. Enjoy Football, Cricket, Badminton, Tennis, NBA, NFL, WWE, MMA, Soccer " />
<script src='https://kit.fontawesome.com/a076d05399.js'></script>

<link href="stylesheet.css" rel="stylesheet">

<link href="css/custom.css" rel="stylesheet">

<link href="css/font-awesome-4.6.3/css/font-awesome.min.css" rel="stylesheet">


<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<style>
      #container { border: 1px solid #808080; width: 500px }
      #txtarea { border: 1px solid #f0f040; background-color: #fffff0; width: 100%; padding: 4px; margin: 5px; }
    </style>
</head>
<body>

<link href="stylesheet.css" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/v4-shims.css">

<link href="css/custom.css" rel="stylesheet">
<style>
  @keyframes spin3D {
    from { transform: rotateY(0deg) }
    to { transform: rotateY(360deg) }
  }
  .spinhov3D:hover {
    animation-name: spin3D;
    animation-duration: 2s;
    animation-iteration-count: 10;
    /* linear | ease | ease-in | ease-out | ease-in-out */
    animation-timing-function: ease-in-out;
  }
</style>
<nav id="topNav" class="navbar navbar-full navbar-static-top navbar-dark bg-inverse m-b-1">
<button class="navbar-toggler hidden-md-up pull-right" type="button" data-toggle="collapse" data-target="#navbar">
&#9776;
</button>
<strong><a class="navbar-brand" href="/index.php"><img class="spinhov3D" src="https://i.imgur.com/8EL6mr3.png" alt="" width="350" height="70" />
<div class="collapse navbar-toggleable-sm" id="navbar"></strong>
<ul class="nav navbar-nav">
<a class="btn btn-outline-primary" style="margin: 10px 1px;" href="/24-hours-channels.php">
<i class="fa fa-desktop" style="font-size:19px;color:red"></i> 24/7 Channels </a>
<a class="btn btn-outline-primary" style="margin: 10px 1px;" href="/index.php">
<i class="fa fa-calendar" style="font-size:19px;color:red"></i> Daily Schedule </a>
<a class="btn btn-outline-primary" style="margin: 10px 1px;" href="https://t.me/daddylive1">
<i class="fab fa-telegram-plane" style="font-size:19px;color:red"></i> Join Telegram </a>
<a class="btn btn-outline-primary" style="margin: 10px 1px;" href="https://discord.gg/cZfyugKGSK">
<i class="fab fa-discord" style="font-size:19px;color:red"></i> Join Discord </a>
<a class="btn btn-outline-primary" style="margin: 10px 1px;" href="/contact-us.php">
<i class="fa fa-edit" style="font-size:19px;color:red"></i> Contact Us </a>
<a class="btn btn-outline-primary" style="margin: 10px 1px;" href="/embed-for-webmasters.php">
<i class="fa fa-code" style="font-size:19px;color:red"></i> For Webmasters </a>
<a class="btn btn-outline-primary" style="margin: 10px 1px;" href="/ipl-schedule.php">
<i class="fa fa-play-circle" style="font-size:19px;color:red"></i> EPL Standings </a>
</ul> 
</ul>
</div>
</nav>
<div class="container-fluid">

</div>

<div class="col-sm-6">

<div class="alert alert-success alert-dismissible" role="alert">
<center><a href="/stream/stream-60.php" target="_blank" rel="noopener"><img class="size-full wp-image-897 aligncenter" src="https://i.imgur.com/Q7PdhBP.jpg" alt="" width="100%" height="10%" /></a></center></div>


<div class="alert alert-success alert-dismissible" role="alert">
<center>

<link href="stylesheet.css" rel="stylesheet">



</center>
</div>

<div class="row">
<article class="col-xs-12">
<div class="alert alert-success alert-dismissible" role="alert">
<center><h3><strong><span style="color: #ff0000;">EPL Table</span></strong></h3></div></center>
<center><div id="fs-standings"></div> <script> (function (w,d,s,o,f,js,fjs) { w['fsStandingsEmbed']=o;w[o] = w[o] || function () { (w[o].q = w[o].q || []).push(arguments) }; js = d.createElement(s), fjs = d.getElementsByTagName(s)[0]; js.id = o; js.src = f; js.async = 1; fjs.parentNode.insertBefore(js, fjs); }(window, document, 'script', 'mw', 'https://cdn.footystats.org/embeds/standings.js')); mw('params', { leagueID: 4759 }); </script></center>
<div class="alert alert-success alert-dismissible" role="alert">
<div class="alert alert-success alert-dismissible" role="alert">
</div>
<center>
<a href="https://www.batman-stream.tv" target="_blank"><img src="https://i.imgur.com/5Pgcewn.jpg" width="430" height="90" alt="Batmanstream Stream Sports - Batmanstream"></a>
<p>Although we try our best to ensure all schedules are accurate,
broadcasters can and will change schedules without warning, especially during off season. Since we cannot physically monitor every single channel, errors will occur from time to time. We thank you for your support and patience in this matter.<br></p>
<p><strong>Copyright &copy; Daddylive 2021 </strong></p> </center>
</div>
</div>
</div>

<div class="col-sm-3">

<div class="card">
<div class="card-header p-b-0">
<h5 class="card-title">
<i class="fa fa-sign-in" aria-hidden="true"></i>
Daddylive Corner
</h5>
</div>
<div class="card-block">
<a href="https://daddylive.click/stream/stream-65.php" target="_blank" rel="noopener"><img class="size-full wp-image-897 aligncenter" src="https://i.imgur.com/NCAiNTk.jpg" alt="" width="100%" height="10%" /></a>
<center><iframe data-aa="1661120" src="//ad.a-ads.com/1661120?size=300x250" scrolling="no" style="width:300px; height:250px; border:0px; padding:0; overflow:hidden" allowtransparency="true"></iframe></center>
</div>
</div>

<div class="card">
<div class="card-header p-b-0">
<h5 class="card-title">
<i class="fa fa-sign-in" aria-hidden="true"></i>
F1 Live Stream
</h5>
</div>
<div class="card-block">
<a href="https://daddylive.click/stream/stream-60.php" target="_blank" rel="noopener"><img class="size-full wp-image-897 aligncenter" src="https://i.imgur.com/H8gZpN0.jpg" alt="" width="100%" height="50%" /></a>
 </div>
</div>

<div class="card">
<div class="card-header p-b-0">
<h5 class="card-title">
<i class="fa fa-tachometer" aria-hidden="true"></i>
User Info & Announcement
</h5>
</div>
<div class="card-block">
<div id="aiscore-free"></div><script language="javascript">document.getElementById("aiscore-free").innerHTML="<iframe src='https://www.aiscore.com?width=1200&theme=black'  height='100%' width='1200' scrolling='auto' border='0' frameborder='0'></iframe>";</script><style>body{margin:0}#aiscore-free{display:flex;justify-content:center;height:100vh}</style>
<p>Watch all televised live soccer matches online, working on any device, anywhere, anytime.
<p>Daddylive serve you live Football streams, football full matches, TV Shows, livesports streaming for free. We want to offer you the best alternative to watch many live sports events online, like football, basketball, soccer, ice hockey, tennis, motor sports, the best competitions and leagues of each sport, the UEFA Champions League, English Premier League, Spanish La Liga, Serie A, Ligue 1, NFL, NHL, NBA and many many more....
<p>Select your match and start your video broadcast. Access free soccer streams in multiple audio commentary languages.
</div>

</div>
</div>
<center>=============================</center>
<footer>
<div class="small-print">
<div class="container">
</div>
</div>
</footer>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.0.0/jquery.min.js" integrity="sha384-THPy051/pYDQGanwU6poAc/hOdQxjnOEXzbT+OuUAFqNqFjL+4IGLBgCJC3ZOShY" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.2.0/js/tether.min.js" integrity="sha384-Plbmg8JY28KFelvJVai01l8WyZzrYWG825m+cZ0eDDS1f7d/js6ikvy1+X+guPIB" crossorigin="anonymous"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.3/js/bootstrap.min.js" integrity="sha384-ux8v3A6CPtOTqOzMKiuo3d/DomGaaClxFYdCu2HPMBEkf6x2xiDyJ7gkXU0MWwaD" crossorigin="anonymous"></script>

<script>
    // Initialize tooltip component
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })

    // Initialize popover component
    $(function () {
      $('[data-toggle="popover"]').popover()
    })
    </script>

<script src="js/holder.min.js"></script>
</body>
</html>
